<?php
require_once 'Classes/PDO.php';
include_once('Classes/DbController.php');

if (isset($_POST['SignUp_button']))
{
    $username=$_POST['LoginName'];
    $password=$_POST['Password'];
    //get all the users to check
    $viewUsers = new DbController();
    $allUsers = $viewUsers->getUser();
    $create='true';

   // check if the username is taken
    foreach($allUsers as $viewUsers)
    {
        if ($username==$viewUsers['username'] )
        {
            echo '<script>alert("This username is taken!")</script>';
            $create='false';
        }
    }
    //check if the password is more tha 8 characters
    if(strlen($password)<=8)
    {
        echo '<script>alert("The Password is too small! You must have at least 8 characters!")</script>';
        $create='false';
    }
    //if it's all alright then add the new user
    if($create=='true')
    {
        $name=$_POST['Name'];
        $lastname=$_POST['LastName'];
        $phone=$_POST['Phone'];
        $email=$_POST['Email'];
        $role=' ';
        $year=date('Y');

        $file=$_FILES['file'];
        $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileSize=$_FILES['file']['size'];
        $fileError=$_FILES['file']['error'];
        $fileType=$_FILES['file']['type'];

        $fileExt=explode('.', $fileName);
        $fileActualExt=strtolower(end($fileExt));

        $image=uniqid('',true).".".$fileActualExt;
        $fileDestination='userImages/'.$image;
        move_uploaded_file($fileTmpName, $fileDestination);


        $addUser = new DbController();
        $addUser -> addUser($username,$name,$lastname,$role,$email,$phone,$image,$password,$year);
        echo '<script>alert("You Sign up Successfully!You will enter in this site soon! ")</script>';
        header('Location: index.php');
    }

}
?>
<!--Form to register a new user-->
<!DOCTYPE html>
<html lang="en">
<title>AEGEAN ICSD</title>
<header>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
</header>
<body style="background-image: url('Images/startimage.jpg');margin-top: 0px; margin-left: 0px; ">
<div style="background: beige;display: flex">
    <div style="margin-left: 10px; flex-grow: 1;">
        <img alt='' src='Images/logo1.svg' width='250px' height='100px' >
    </div>
    <div style="flex-grow: 2;margin-top: 15px;margin-left: 30px">
        <p><b>If you like to see the Curriculum of the University please click </b></p>
    </div>
    <div style="flex-grow: 3;margin-top: 30px; margin-left:-370px;">
        <a href="ShowLessons.php">here</a>
    </div>
</div>

<div style="width: 400px;padding-left:550px;padding-top: 0px;">
    <form action="" method="POST" enctype="multipart/form-data">
        <div style="background: black;padding-left: 50px;height: 750px;box-shadow: 12px 12px 2px 1px rgba(0, 0, 255, .2);"><br>
            <h1 style="padding-left: 70px;color: azure; font-size: 2.75rem;font-weight: 100;margin: 0 0 1rem;text-transform: uppercase;">Sign Up</h1>

            <label style="color: azure;"><b>Image</b></label><br>
            <input type="file" name="file" required="" accept="*/image" size=" " style="color:#ff0000;" onchange="loadFile(event)" style="display: none;" ><br>
            <div style="padding-left: 70px;">
                <img src="userImages/guest-user.jpg" style="border-radius: 50%" id="output" width="130px" /><br>
            </div>

            <label style="color: azure;"><b>Username</b></label><br>
            <input type="text" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="LoginName" value="" required/><br>

            <label style="color: azure;"><b>Name</b></label><br>
            <input type="text" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="Name" value="" required/><br>

            <label style="color: azure;"><b>Lastname</b></label><br>
            <input type="text" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="LastName" value="" /><br>

            <label style="color: azure;"><b>Phone</b></label><br>
            <input type="text" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="Phone" value="" /><br>

            <label style="color: azure;"><b>Email</b></label><br>
            <input type="text" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="Email" value="" /><br>

            <label style="color: azure"><b>Password</b></label><br>
            <input type="password" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="Password" value="" /><br><br>
            <div style="padding-left:20%">
                <input type="submit" style="background-image: linear-gradient(160deg, #8ceabb 0%, #378f7b 100%);color: #fff;width: 60%;border: 1px solid #242c37;border-radius: 999px;text-align: center;font-size:25px ;margin-bottom: 4rem;" value="Sign Up" name="SignUp_button"><br>

            </div>

    </form>
</div>


</body>
</html>

<script>
    //Show me the new image of the new user in the system
    var loadFile = function(event) {
        var image = document.getElementById('output');
        image.src = URL.createObjectURL(event.target.files[0]);
    };
</script>