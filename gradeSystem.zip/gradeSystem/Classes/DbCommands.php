<?php
include_once('DbConnection.php');

class DbCommands extends DbConnection
{
    //FUNCTION TO ADD A USER
    protected function addUserDb($username,$name,$lastname,$role,$email,$phone,$image,$password,$year)
    {
        $sql = "INSERT INTO all_users (username,firstname,lastname,urole,email,phone,image,password,uyear) VALUES(?,?,?,?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        return $stmt->execute([$username,$name,$lastname,$role,$email,$phone,$image,$password,$year]);

    }
    //FUNCTION TO DELETE A USER
    protected function deleteUserDb ($u_id)
    {
        $sql = "DELETE FROM all_users WHERE u_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$u_id]);

        return $result;
    }
    //FUNCTION TO UPDATE A USER
    protected function updateUserDb ($u_id, $username,$name,$lastname,$role,$email,$phone,$password,$year,$kind)
    {

        $sql = "UPDATE all_users SET username=?, firstname=?, lastname=?, urole=?, email=?, phone=?, password=?, uyear=?, kind=? WHERE u_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($username,$name,$lastname,$role,$email,$phone,$password,$year,$kind,$u_id));
        return $result;
    }
    //FUNCTION TO SEE ALL THE USERS
    protected function getUserDb()
    {
        $sql = "SELECT *FROM all_users ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        return $result;
    }
    //FUNCTION TO UPDATE THE IMAGE OF A USER
    protected  function changeImageDb($u_id,$image)
    {
        $sql = "UPDATE all_users SET image=? WHERE u_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($image,$u_id));
        return $result;
    }
    //FUNCTION TO SEE ALL THE INFORMATION FOR EVERY LESSON
    protected function getinfoLessonDb()
    {
        $sql = "SELECT *FROM lesson,all_users WHERE lesson.t_id=all_users.u_id ORDER BY semester ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        return $result;
    }
    //FUNCTION TO SEE ALL THE USERS IN THE SYSTEM WITH THE ROLE "TEACHER"
    protected function getProfessorsDb()
    {
        $sql = "SELECT u_id,firstname,lastname,image FROM all_users WHERE all_users.urole='Teacher'  ORDER BY kind ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        return $result;
    }
    //FUNTION TO ADD A LESSON
    protected function addLessonDb($t_id,$title,$semester,$theory,$lab)
    {
        $sql = "INSERT INTO lesson (t_id,title,semester,theory,lab) VALUES(?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        return $stmt->execute([$t_id,$title,$semester,$theory,$lab]);
    }
    //FUNTION TO UPDATE A LESSON
    protected function updateLessonDb($l_id,$t_id,$title,$semester,$theory,$lab)
    {
        $sql = "UPDATE lesson SET t_id=?,title=?,semester=?,theory=?,lab=? WHERE l_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($t_id,$title,$semester,$theory,$lab,$l_id));
        return $result;
    }
    //FUNTION TO DELETE A LESSON
    protected function deleteLessonDb($l_id)
    {
        $sql = "DELETE FROM lesson WHERE l_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$l_id]);

        return $result;
    }

    //FUNCTION TO DELETE A PARTICIANT FROM A LESSON
    protected function deleteJoinDb($j_id)
    {
        $sql = "DELETE FROM join_lesson WHERE j_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$j_id]);

        return $result;
    }
    //FUNCTION TO UPDATE THE GRADE OF A PARTICIPANT
    protected function updateJoinDb($theorygrade,$labgrade,$grade,$j_id)
    {
        $sql = "UPDATE join_lesson SET theorygrade=?,labgrade=? ,grade=? WHERE j_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($theorygrade,$labgrade,$grade,$j_id));
        return $result;
    }
    //FUNCTION TO SEE THE PARTICIPANTS IN A LESSON
    protected function getaJoinDb($l_id)
    {
        $sql = "SELECT * FROM all_users,join_lesson WHERE all_users.u_id=join_lesson.s_id AND join_lesson.l_id=? ORDER BY join_lesson.date AND join_lesson.finalisegrade";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$l_id]);
        $result = $stmt->fetchAll();
        return $result;
    }
    //FUNCTION TO GET SOME INFORMATION FOR A LESSON LIKE THE PROFESSOR'S NAME AND LESSON'S TITLE
    protected function getalessonDb($l_id)
    {
        $sql = "SELECT lesson.l_id,lesson.t_id,lesson.title,all_users.u_id,all_users.firstname,all_users.lastname FROM all_users,lesson WHERE lesson.l_id=? and all_users.u_id=lesson.t_id ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$l_id]);
        $result = $stmt->fetchAll();
        return $result;
    }
    //FUNCTION TO FINALISE A GRADE OF A PARTICIPANTS-STUDENT
    protected function finaliseGradeDb($finalise,$j_id)
    {
        $sql = "UPDATE join_lesson SET finalisegrade=? WHERE j_id=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($finalise,$j_id));
        return $result;
    }

    //FUNCTION TO FINALSE THE GRADES OF THE PARTICIPANTS-STUDENTS WHO PASSED THE LESSON
    protected function finaliseAllGradesDb($l_id)
    {
        $finalisegrade=1;
        $sql = "UPDATE join_lesson SET finalisegrade=? WHERE l_id=? AND grade >= 5";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($finalisegrade,$l_id));
        return $result;
    }

    //FUNCTION TO DELETE ALL THE FINALISED PARTICIPANTS WHO PASSED THE LESSON
    protected function deleteFinalJoinsDb($l_id)
    {
        $finalisegrade=1;
        $sql = "DELETE FROM join_lesson WHERE l_id=? AND finalisegrade=?";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$l_id,$finalisegrade]);

        return $result;
    }
    //FUNCTION TO DELETE THE PARTICIPANTS WHO ARE NOT PASSED THE LESSON FOR SOME YEARS
    protected function deleteJoinYearDb($l_id,$y)
    {
        $year=date("Y",strtotime('-'. $y .'year'));
        $sql = "DELETE FROM join_lesson WHERE l_id= ? AND YEAR(date) < ? ";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$l_id,$year]);

        return $result;
    }

    //FUNCTION TO SHOW THE LESSON OF A PROFESSOR
    protected function GetProfessorLessonDb($t_id)
    {
        $sql = "SELECT *FROM lesson WHERE t_id= ? ORDER BY semester ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$t_id]);
        $result = $stmt->fetchAll();

        return $result;
    }
    //FUNCTION TO ADD A PARTICIPANT-STUDENT IN A LESSON
    protected function AddPartitipantDb($l_id,$s_id)
    {
        $date=date("Y-m-d");
        $finalisegrade=0;
        $theorygrade=0;
        $labgrade=0;
        $grade=0;
        $sql = "INSERT INTO join_lesson (l_id,s_id,theorygrade,labgrade,grade,date,finalisegrade) VALUES(?,?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        return $stmt->execute([$l_id,$s_id,$theorygrade,$labgrade,$grade,$date,$finalisegrade]);
    }
    //FUNCTION TO CHECK IF A STUDENT PARTICIPATE IN A LESSON
    protected function CheckJoinsDb()
    {
        $sql = "SELECT l_id,s_id FROM join_lesson ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    //FUNCTION FOR A STUDENT TO CANCEL A JOIN TO A LESSON
    protected function CancelJoinDb($l_id,$s_id)
    {
        $sql = "DELETE FROM join_lesson WHERE l_id= ? AND s_id=? ";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$l_id,$s_id]);

        return $result;
    }
    //FUNCTION FOR A STUDENT TO SEE HIS/HER GRADES
    protected function GetJoinsForAStudentDb($s_id)
    {
        $sql = "SELECT * FROM lesson, join_lesson WHERE lesson.l_id=join_lesson.l_id AND join_lesson.s_id= ? ORDER BY date DESC  ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$s_id]);
        $result = $stmt->fetchAll();
        return $result;
    }
    //FUNCTION TO FINALSE THE GRADES OF THE PARTICIPANTS-STUDENTS WHO PASSED THE LESSON
    protected function finaliseAllGrades2Db($l_id)
    {
        $finalisegrade=1;
        $sql = "UPDATE join_lesson SET finalisegrade=? WHERE l_id=? AND labgrade<5 AND theorygrade<5; ";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($finalisegrade,$l_id));
        return $result;
    }
    //FUNCTION TO ALLOW A NEW JOIN
    protected function AllowJoinsDb()
    {
        $allow=1;
        $sql = "UPDATE allowjoins SET Allow =? ";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($allow));
        return $result;
    }
    //FUNCTION TO NOT ALLOW A NEW JOIN
    protected function NotAllowJoinsDb()
    {
        $allow=0;
        $sql = "UPDATE allowjoins SET Allow =? ";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($allow));
        return $result;
    }
    //FUNCTION TO RETURN IF A STUDENT CAN JOIN A LESSON
    protected function CheckAllowDb()
    {
        $sql = "SELECT *FROM allowjoins ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    //UPDATE THE DATA FROM THE FILE THAT IS IMPORTED FROM A TEATHER OR FROM THE ADMIN
    protected function ImportGradesDb($j_id,$theorygrade,$labgrade,$grade)
    {
        $sql = "UPDATE join_lesson SET theorygrade=?,labgrade=?,grade=? WHERE j_id=? ; ";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute(array($theorygrade,$labgrade,$grade,$j_id));
        return $result;
    }
}
