<?php
include_once('DbCommands.php');

class DbController extends DbCommands
{
    public function addUser($username,$name,$lastname,$role,$email,$phone,$image,$password,$year)
    {
        return $this->addUserDb($username,$name,$lastname,$role,$email,$phone,$image,$password,$year);
    }

    public function deleteUser($u_id)
    {
        return $this->deleteUserDb($u_id);
    }

    public function updateUser($u_id, $username,$name,$lastname,$role,$email,$phone,$password,$year,$kind)
    {
        return $this->updateUserDb($u_id, $username,$name,$lastname,$role,$email,$phone,$password,$year,$kind);
    }
    public function getUser()
    {
        return $this->getUserDb();
    }

    public function changeImage($u_id,$image)
    {
        return $this->changeImageDb($u_id,$image);
    }

    public function getinfoLesson()
    {
        return $this->getinfoLessonDb();
    }

    public function getProfessors()
    {
        return $this->getProfessorsDb();
    }

    public function addLesson($t_id,$title,$semester,$theory,$lab)
    {
        return $this->addLessonDb($t_id,$title,$semester,$theory,$lab);
    }

    public function updateLesson($l_id,$t_id,$title,$semester,$theory,$lab)
    {
        return $this->updateLessonDb($l_id,$t_id,$title,$semester,$theory,$lab);
    }

    public function deleteLesson($l_id)
    {
        return $this->deleteLessonDb($l_id);
    }
    public function getaJoin($l_id)
    {
        return $this->getaJoinDb($l_id);
    }
    public function getalesson($l_id)
    {
        return $this->getalessonDb($l_id);
    }
    public function deleteJoin($j_id)
    {
        return $this->deleteJoinDb($j_id);
    }

    public function updateJoin($theorygrade,$labgrade,$grade,$j_id)
    {
        return $this->updateJoinDb($theorygrade,$labgrade,$grade,$j_id);
    }
    public function finaliseGrade($finalise,$j_id)
    {
        return $this->finaliseGradeDb($finalise,$j_id);
    }
    public function finaliseAllGrades($l_id)
    {
        return $this->finaliseAllGradesDb($l_id);
    }
    public function deleteFinalJoins($l_id)
    {
        return $this->deleteFinalJoinsDb($l_id);
    }
    public function deleteJoinYear($l_id,$y)
    {
        return $this->deleteJoinYearDb($l_id,$y);
    }
    public function GetProfessorLesson($t_id)
    {
        return $this->GetProfessorLessonDb($t_id);
    }
    public function AddPartitipant($l_id,$s_id)
    {
        return $this->AddPartitipantDb($l_id,$s_id);
    }
    public function CheckJoins()
    {
        return $this->CheckJoinsDb();
    }
    public function CancelJoin($l_id,$s_id)
    {
        return $this->CancelJoinDb($l_id,$s_id);
    }
    public function GetJoinsForAStudent($s_id)
    {
        return $this->GetJoinsForAStudentDb($s_id);
    }
    public function finaliseAllGrades2($l_id)
    {
        return $this->finaliseAllGrades2Db($l_id);
    }
    public function AllowJoins()
    {
        return $this->AllowJoinsDb();
    }
    public function NotAllowJoins()
    {
        return $this->NotAllowJoinsDb();
    }
    public function CheckAllow()
    {
        return $this->CheckAllowDb();
    }
    public function ImportGrades($j_id,$theorygrade,$labgrade,$grade)
    {
        return $this->ImportGradesDb($j_id,$theorygrade,$labgrade,$grade);
    }

}

