<?php
require_once 'Classes/PDO.php';
include_once('Classes/DbController.php');
session_start();

if(isset($_POST['login_button']))
{
    //Pairnei ta stoixeia apo th form
    $loginame=$_POST['LoginName'];
    $password=$_POST['Password'];
    $un='false'; //Metavlhth gia to an to username pou dothike einai swsto
    $access='false'; //metavlhth pou epitrepei h apotrepei  thn eisodo

    //phgaine sth vash sto pinaka me tous xrhstes gia elegxo
    $viewUsers = new DbController();
    $allUsers = $viewUsers->getUser();

    foreach($allUsers as $viewUsers)
    {
//        An to username einai swsto
        if ($loginame==$viewUsers['username'] )
        {
            $un='true';
//            An o kwdikos einai swstos elekse kai to rolo tou xrhsth gia thn emgfanish ths katallhlhw selidas
            if($password==$viewUsers['password'])
            {
               //-----------ADMIN--------------//
               if($viewUsers['urole']=='Admin')
               {
                   $access='true';
                   $_SESSION['access']=$access;
                   $_SESSION['User_id']=$viewUsers['u_id'];
                   $_SESSION['role']='Admin';
                   header('Location: AdminProfile.php');
               }

                //-----------STUDENT---------//
                if($viewUsers['urole']=='Student')
                {
                    $access='true';
                    $_SESSION['access']=$access;
                    $_SESSION['User_id']=$viewUsers['u_id'];
                    $_SESSION['role']='Student';
                    header('Location: UserProfile.php');
                }

                //-----------TEACHER---------//
                if($viewUsers['urole']=='Teacher')
                {
                    $access='true';
                    $_SESSION['access']=$access;
                    $_SESSION['User_id']=$viewUsers['u_id'];
                    $_SESSION['role']='Teacher';
                    header('Location: UserProfile.php');
                }

                //-----------GRAMMATEIA---------//
//                if($viewUsers['urole']=='Secretariat')
//                {
//                    $access='true';
//                    $_SESSION['access']=$access;
//                    $_SESSION['User_id']=$viewUsers['u_id'];
//                    $_SESSION['role']='Admin';
//                    header('Location: AdminProfile.php');

//                }

                //-----------NO ROLE YET---------//
                if($viewUsers['urole']==' ')
                {
                    $un='true';
                    echo '<script>alert("You are not accepted yet in the form please try again later")</script>';
                }
            }
//            An den einai swstos o kwdikos
           else
           {
               echo '<script>alert("Your password is not correct!!!")</script>';
               $un='true';
           }

        }

    }
//    An einai lathos to username
    if($un=='false')
    {
        echo '<script>alert("Your username is not correct!!!")</script>';
    }
}
?>
<!-------------------------------------FORM FOR LOG IN----------------------------------------------------------------->
<!DOCTYPE html>
<html>
<title>AEGEAN ICSD</title>
<header>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
</header>
<body style="background-image: url('Images/startimage.jpg'); margin-top: 0px; margin-left: 0px;">
<div style="background: beige;display: flex">
    <div style="margin-left: 10px; flex-grow: 1;">
        <img alt='' src='Images/logo1.svg' width='250px' height='100px' >
    </div>
    <div style="flex-grow: 2;margin-top: 15px;margin-left: 30px">
        <p><b>If you like to see the Curriculum of the University please click </b></p>

    </div>
    <!--LINK TO SEE THE COURSES OF THE UNIVERSITY    -->
    <div style="flex-grow: 3;margin-top: 30px; margin-left:-380px;">
        <a href="ShowLessons.php">here</a>
    </div>
</div>

<div style="width: 400px;padding-left:550px;padding-top: 100px">
    <form method="post">
        <div style="background: black;padding-left: 50px;height: 380px;box-shadow: 12px 12px 2px 1px rgba(0, 0, 255, .2);"><br>
            <h1 style="padding-left: 70px;color: azure; font-size: 2.75rem;font-weight: 100;margin: 0 0 1rem;text-transform: uppercase;">Log In</h1><br>
            <label style="color: azure;"><b>Username</b></label><br>
            <input type="text" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="LoginName" value="" /><br><br>

            <label style="color: azure"><b>Password</b></label><br>
            <input type="password" style="margin-bottom: 1rem;outline: 0;padding: .5rem 1rem; width: 70%;border: 1px solid #242c37;border-radius: 999px;text-align: center;" name="Password" value="" /><br><br>
            <div style="padding-left:20%">
                <input type="submit"  style="background-image: linear-gradient(160deg, #8ceabb 0%, #378f7b 100%);color: #fff;margin-bottom: 1rem;width: 50%;border: 1px solid #242c37;border-radius: 999px;text-align: center;font-size:18px " value="log In" name="login_button"><br>

            </div>
            <!--LINK TO SING UP IN THE SYSTEM-->
            <div style="padding-left:70%">
                <a href="register.php" style="font-size:20px;color: white;outline: 0;padding: .5rem .5rem; width: 50%;text-align: right;background: black;">Sign Up</a>
            </div>


    </form>
</div>


</body>
</html>

