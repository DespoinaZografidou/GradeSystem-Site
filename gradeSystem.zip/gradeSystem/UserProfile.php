<?php
require_once 'Classes/PDO.php';
include_once('Classes/DbController.php');

session_start();
//if you not allowed to insert in the site through the login form go back to the login form
if( $_SESSION['access']!='true' )
{
    header('Location: index.php');
}
//get the user who he/she is in the system for the side bar
$viewUsers = new DbController();
$allUsers = $viewUsers->getUser();

//UPDATE THE STUDENT'S/TEACHER'S DATA
if(isset($_POST['Update-submit']))
{
    $username=$_POST['username'];
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $password=$_POST['password'];
    $role=$_POST['role'];
    $u_id=$_SESSION['User_id'];
    $year=$_POST['year'];
    $kind=$_POST['kind'];
    $updateUser = new DbController();
    $updateUser -> updateUser($u_id, $username,$firstname,$lastname,$role,$email,$phone,$password,$year,$kind);
}
//UPDATE THE STUDENT'S/TEACHER'S IMAGE
if(isset($_POST['newImage-submit']))
{
    echo $_FILES['file']['type'];
    $file=$_FILES['file'];
    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize=$_FILES['file']['size'];
    $fileError=$_FILES['file']['error'];
    $fileType=$_FILES['file']['type'];

    $fileExt=explode('.', $fileName);
    $fileActualExt=strtolower(end($fileExt));

    $image=uniqid('',true).".".$fileActualExt;
    $fileDestination='userImages/'.$image;
    move_uploaded_file($fileTmpName, $fileDestination);

    $newImage=new DbController();
    $newImage->changeImage($_SESSION['User_id'],$image);
}


?>
<!DOCTYPE html>
<html lang="en">
<title>AEGEAN ICSD</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
    body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
    .w3-third img{margin-bottom: -6px; opacity: 0.8; cursor: pointer}
    .w3-third img:hover{opacity: 1}
</style>
<body class="w3-light-grey w3-content" style="max-width:1600px">

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-animate-left w3-text-grey w3-collapse w3-top w3-center" style="z-index:3;width:180px;font-weight:bold" id="mySidebar"><br>
    <img alt='' src='Images/logo.JPG'width='180px' height='150px' ><hr>
    <?php

    foreach($allUsers as $row)
    {
        if($row['u_id']==$_SESSION['User_id']) {
            echo "<img  src='userImages/".$row['image']."'width='100px' height='100px' style=' border-radius: 50%;'><br>";
            echo $row['username'];
        }
    }

    ?>
    <hr>
    <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-padding w3-hide-large">CLOSE</a>
    <a href="Profile.php" onclick="w3_close()" class="w3-bar-item w3-button">Profile</a>
    <?php
    if($_SESSION['role']=='Teacher')
    {
        ?>
        <a href="Professor'sLessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Lessons</a>
    <?php
    }
    else{
    ?>
        <a href="UserSeeGrades&Lessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Grades</a>
        <?php
        //check if the Courses' Declaration is open
        $checkallow=new DbController();
        $allow=$checkallow->CheckAllow();
        foreach ($allow as $a)  {
            if($a['Allow']==1){
        ?>
        <a href="UsersJoinLessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Courses' Declaration</a>

    <?php
            }
        }
    }
    ?>
    <a href="index.php" onclick="w3_close()" class="w3-bar-item w3-button">Log Out</a>
</nav>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-white w3-xlarge w3-padding-16">
    <span class="w3-left w3-padding">SOME NAME</span>
    <a href="javascript:void(0)" class="w3-right w3-button w3-white" onclick="w3_open()">☰</a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:180px">

    <!-- Push down content on small screens -->
    <div class="w3-hide-large" style="margin-top:83px"></div>



    <!-- Modal for full size images on click-->
    <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
        <span class="w3-button w3-black w3-xlarge w3-display-topright">×</span>
        <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
            <img id="img01" class="w3-image">
            <p id="caption"></p>
        </div>
    </div>

    <!-- image section -->
    <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32" id="about" >
        <div class="w3-content w3-justify" style="max-width:600px">
            <h2 style="color: aliceblue"><b>My Profile Info</b></h2>
            <p>If you like to change your profile picture click on the button "Choose File" pick an image from your device and then click the button "Save the New Image"</p>
            <form method="post" enctype="multipart/form-data">
                <?php

                foreach($allUsers as $row)
                {
                    if($row['u_id']==$_SESSION['User_id']) {
                        echo "<img id=\"output\" src='userImages/".$row['image']."'width='500px' height='500px' style=' border-radius: 50%;'>";
                    }
                }

                ?>
                <input type="file" name="file" accept="*/image" size=" " style="color:#ff0000;" onchange="loadFile(event)" style="display: none;" >
                <input type="submit" style="background-image: linear-gradient(160deg, #8ceabb 0%, #378f7b 100%);color: #fff;margin-bottom: 1rem;width: 30%;border: 1px solid #242c37;border-radius: 999px;text-align: center;font-size:16px " name="newImage-submit" value="Save the New Image"/><br><br>
            </form>
        </div>

    </div>


    <!--  section -->
    <div class="w3-container w3-light-grey w3-padding-32 w3-padding-large" id="contact">
        <div class="w3-content" style="max-width:600px">


        </div>
    </div>

    <!-- Form to update student's/teacher's data -->
    <footer class="w3-container w3-padding-32 w3-grey">
        <div class="w3-row-padding">
            <div class="w3-third">

                <p>If you like to change on of the following please after your changes enter the button "Save the Changes".</p>
            </div>

            <div class="w3-third">
                <h2 style="color: aliceblue"><b>My Profile Info</b></h2><br>
                <form method="post" enctype="multipart/form-data">
                    <?php

                    foreach($allUsers as $row)
                    {
                        if($row['u_id']==$_SESSION['User_id']) {

                            ?>
                            <label for="p_name1" ><b>Username</b></label><br>
                            <input type="text"  value="<?php echo  $row['username']; ?>" name="username"  ><br>
                            <br>
                            <label for="p_name1" ><b>Fist Name</b></label><br>
                            <input type="text"  value="<?php echo  $row['firstname']; ?>" name="firstname"  ><br>
                            <br>
                            <label for="p_name1" ><b>Last Name</b></label><br>
                            <input type="text"  value="<?php echo  $row['lastname']; ?>" name="lastname"  ><br>
                            <br>
                            <label for="p_name1" ><b>Email</b></label><br>
                            <input type="text"  value="<?php echo  $row['email']; ?>" name="email"  ><br>
                            <br>
                            <label for="p_name1" ><b>Phone</b></label><br>
                            <input type="text"  value="<?php echo  $row['phone']; ?>" name="phone"  ><br>
                            <br>
                            <label for="p_name1" ><b>Password</b></label><br>
                            <input type="text"  value="<?php echo  $row['password']; ?>" name="password"  ><br>
                            <br>
                            <label for="p_name1" ><b>Role</b></label><br>
                            <input type="text"  value="<?php echo  $row['urole']; ?>" name="role1"  disabled><br>
                            <input type="hidden"  value="<?php echo  $row['urole']; ?>" name="role" ><br>

                            <label for="text" ><b>Year of Admission</b></label><br>
                            <input type="text"  value="<?php echo  $row['uyear']; ?>" name="year1"  disabled><br>
                            <input type="hidden"  value="<?php echo  $row['uyear']; ?>" name="year"  ><br>

                            <label for="text" ><b>Specific Role </b></label><br>
                            <input type="text"  value="<?php echo  $row['kind']; ?>" name="kind1"  disabled><br>
                            <input type="hidden"  value="<?php echo  $row['kind']; ?>" name="kind"  ><br>

                            <?php
                        }
                    }

                    ?>
                    <input type="submit" name="Update-submit" value="Save The Changes">
                </form>
            </div>


        </div>
    </footer>
</div>

<div class="w3-black w3-center w3-padding-24"></div>

<!-- End page content -->
</div>

<script>
    // Script to open and close sidebar
    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }

    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }

    // Modal Image Gallery
    function onClick(element) {
        document.getElementById("img01").src = element.src;
        document.getElementById("modal01").style.display = "block";
        var captionText = document.getElementById("caption");
        captionText.innerHTML = element.alt;
    }

</script>


</body>
</html>
<!--Show the new image-->
<script>
    var loadFile = function(event) {
        var image = document.getElementById('output');
        image.src = URL.createObjectURL(event.target.files[0]);
    };
</script>
