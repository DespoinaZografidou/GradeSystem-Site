<?php

require_once 'Classes/PDO.php';
include_once('Classes/DbController.php');

require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;

//----------------------ADMIN EXPORT USERS' DATA--------------------------
if(isset($_POST["ExportUsers"]))
{
    $users = new DbController();
    $result = $users->getUser();

    $file = new Spreadsheet();

    $active_sheet = $file->getActiveSheet();

    $active_sheet->setCellValue('A1', 'Username');
    $active_sheet->setCellValue('B1', 'Firstname');
    $active_sheet->setCellValue('C1', 'Lastname');
    $active_sheet->setCellValue('D1', 'Role in the System');
    $active_sheet->setCellValue('E1', 'Email');
    $active_sheet->setCellValue('F1', 'Phone');
    $active_sheet->setCellValue('G1', 'Register Year');
    $active_sheet->setCellValue('H1', 'Member Type in University');

    $count = 2;

    foreach($result as $row)
    {
        $active_sheet->setCellValue('A' . $count, $row["username"]);
        $active_sheet->setCellValue('B' . $count, $row["firstname"]);
        $active_sheet->setCellValue('C' . $count, $row["lastname"]);
        $active_sheet->setCellValue('D' . $count, $row["urole"]);
        $active_sheet->setCellValue('E' . $count, $row["email"]);
        $active_sheet->setCellValue('F' . $count, $row["phone"]);
        $active_sheet->setCellValue('G' . $count, $row["uyear"]);
        $active_sheet->setCellValue('H' . $count, $row["kind"]);

        $count = $count + 1;
    }

    $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($file, $_POST["file_type"]);

    $name='UsersData'. date("Y-m-d");
    $file_name =  $name. '.' . strtolower($_POST["file_type"]);

    $writer->save($file_name);

    header('Content-Type: application/x-www-form-urlencoded;');

    header('Content-Transfer-Encoding: UTF-8');

    header("Content-disposition: attachment; filename=\"".$file_name."\"");

    readfile($file_name);

    unlink($file_name);

    exit;
    header('Location: AdminViewUser.php');

}

//--------------------------------ADMIN EXPORT LESSONS' DATA-----------------------
if(isset($_POST["ExportLessons"]))
{
    $lessons = new DbController();
    $result = $lessons->getinfoLesson();

    $file = new Spreadsheet();

    $active_sheet = $file->getActiveSheet();

    $active_sheet->setCellValue('A1', 'Title');
    $active_sheet->setCellValue('B1', 'Semester');
    $active_sheet->setCellValue('C1', 'Theory(%)');
    $active_sheet->setCellValue('D1', 'Labratory(%)');
    $active_sheet->setCellValue('E1', 'Professor');

    $count = 2;

    foreach($result as $row)
    {
        $professor=$row['firstname'].' '.$row['lastname'] ;
        $active_sheet->setCellValue('A' . $count, $row["title"]);
        $active_sheet->setCellValue('B' . $count, $row["semester"]);
        $active_sheet->setCellValue('C' . $count, $row["theory"]);
        $active_sheet->setCellValue('D' . $count, $row["lab"]);
        $active_sheet->setCellValue('E' . $count, $professor);

        $count = $count + 1;
    }

    $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($file, $_POST["file_type"]);

    $name='LessonsData'. date("Y-m-d");
    $file_name =  $name. '.' . strtolower($_POST["file_type"]);

    $writer->save($file_name);

    header('Content-Type: application/x-www-form-urlencoded;');

    header('Content-Transfer-Encoding: UTF-8');

    header("Content-disposition: attachment; filename=\"".$file_name."\"");

    readfile($file_name);

    unlink($file_name);

    exit;
    header('Location: AdminControlLessons.php');

}
//----------------------ADMIN EXPORTS PARTICIPANT'S DATA FOR A LESSON-------------------------

if(isset($_POST["ExportParticipants"]))
{
    $part = new DbController();
    $result = $part->getAJoin($_POST['id']);

    $file = new Spreadsheet();

    $active_sheet = $file->getActiveSheet();

    $active_sheet->setCellValue('A1', 'Firstname');
    $active_sheet->setCellValue('B1', 'Lastname');
    $active_sheet->setCellValue('C1', 'Theory Grade');
    $active_sheet->setCellValue('D1', 'Labratory Grade');
    $active_sheet->setCellValue('E1', 'Final Grade');

    $count = 2;

    foreach($result as $row)
    {

        $active_sheet->setCellValue('A' . $count, $row["firstname"]);
        $active_sheet->setCellValue('B' . $count, $row["lastname"]);
        $active_sheet->setCellValue('C' . $count, $row["theorygrade"]);
        $active_sheet->setCellValue('D' . $count, $row["labgrade"]);
        $active_sheet->setCellValue('E' . $count,$row["grade"] );
        if($row['finalisegrade']==0)
        {
            $active_sheet->setCellValue('F' . $count,'Not Finalised' );
        }
        else{
            $active_sheet->setCellValue('F' . $count,'Finalised' );
        }


        $count = $count + 1;
    }

    $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($file, $_POST["file_type"]);

    $name= $_POST['title']. date("Y-m-d");
    $file_name =  $name. '.' . strtolower($_POST["file_type"]);

    $writer->save($file_name);

    header('Content-Type: application/x-www-form-urlencoded;');

    header('Content-Transfer-Encoding: UTF-8');

    header("Content-disposition: attachment; filename=\"".$file_name."\"");

    readfile($file_name);

    unlink($file_name);

    exit;
    header('Location: AdminViewTheParticipantsForALesson.php');

}
//-----------------------ADMIN/TEACHER EXPORT THE FILE THAT NEEDS TO FILL WITH GRADES--------------------
if(isset($_POST["Get_the_file"]))
{

    $part = new DbController();
    $result = $part->getAJoin($_POST['lesson']);

    $file = new Spreadsheet();

    $active_sheet = $file->getActiveSheet();

    $active_sheet->setCellValue('A1', 'No');
    $active_sheet->setCellValue('B1', 'AM');
    $active_sheet->setCellValue('C1', 'Firstname');
    $active_sheet->setCellValue('D1', 'Lastname');
    $active_sheet->setCellValue('E1', 'Theory Grade');
    $active_sheet->setCellValue('F1', 'Labratory Grade');

    $count = 2;

    foreach($result as $row)
    {
        if($row['finalisegrade']==0)
        {
            $active_sheet->setCellValue('A' . $count, $row["j_id"]);
            $active_sheet->setCellValue('B' . $count, $row["username"]);
            $active_sheet->setCellValue('C' . $count, $row["firstname"]);
            $active_sheet->setCellValue('D' . $count, $row["lastname"]);
            $active_sheet->setCellValue('E' . $count, $row["theorygrade"]);
            $active_sheet->setCellValue('F' . $count, $row["labgrade"]);
            $count = $count + 1;
        }


    }

    $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($file, $_POST["givemethefile"]);

    $name=  date($_POST['title']."Y-m-d");
    $file_name =  $name. '.' . strtolower($_POST["givemethefile"]);

    $writer->save($file_name);

    header('Content-Type: application/x-www-form-urlencoded;');

    header('Content-Transfer-Encoding: UTF-8');

    header("Content-disposition: attachment; filename=\"".$file_name."\"");

    readfile($file_name);

    unlink($file_name);

    exit;
    header('Location: AdminViewTheParticipantsForALesson.php');

}
?>





