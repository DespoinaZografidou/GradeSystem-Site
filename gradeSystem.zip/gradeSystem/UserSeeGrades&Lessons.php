<?php
require_once 'Classes/PDO.php';
include_once('Classes/DbController.php');
session_start();
//if you not allowed to insert in the site through the login form go back to the login form
if( $_SESSION['access']!='true')
{
    header('Location: index.php');
}
//Show the performance of the student
$viewLessons = new DbController();
$yourlessons = $viewLessons->GetJoinsForAStudent($_SESSION['User_id']);

//get the user who he/she is in the system for the side bar
$viewUsers = new DbController();
$allUsers = $viewUsers->getUser();


?>

<!DOCTYPE html>
<html lang="en">
<title>AEGEAN ICSD</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="Css/Tables.css"/>
<style>
    body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
    .w3-third img{margin-bottom: -6px; opacity: 0.8; cursor: pointer}
    .w3-third img:hover{opacity: 1}
</style>
<body class="w3-light-grey w3-content" style="max-width:1600px">

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-animate-left w3-text-grey w3-collapse w3-top w3-center" style="z-index:3;width:180px;font-weight:bold" id="mySidebar"><br>
    <img alt='' src='Images/logo.JPG' width='180px' height='150px' ><br>
    <hr>
    <?php
     $s_name='';
     $s_username='';
    foreach($allUsers as $row)
    {
        if($row['u_id']==$_SESSION['User_id']) {
            echo "<img alt='' src='userImages/".$row['image']."' width='100px' height='100px' style=' border-radius: 50%;'><br>";
            echo $row['username'];
            $s_name=$row['lastname'].' '.$row['firstname'];
            $s_username=$row['username'];
        }
    }

    ?>
    <hr>
    <a href="UserProfile.php" onclick="w3_close()" class="w3-bar-item w3-button">Profile</a>

    <?php
    if($_SESSION['role']=='Teacher')
    {
        ?>
        <a href="Professor'sLessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Lessons</a>
        <?php
    }
    else{
        ?>
        <a href="UserSeeGrades&Lessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Grades</a>

        <?php
        //check if the Courses' Declaration is open
        $checkallow=new DbController();
        $allow=$checkallow->CheckAllow();
        foreach ($allow as $a)  {
            if($a['Allow']==1){
                ?>
                <a href="UsersJoinLessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Courses' Declaration</a>

                <?php
            }
        }
    }
    ?>
    <a href="index.php" onclick="w3_close()" class="w3-bar-item w3-button">Log Out</a>
    <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-padding w3-hide-large">CLOSE</a>
</nav>


<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-white w3-xlarge w3-padding-16">
    <span class="w3-left w3-padding">MENU</span>
    <a href="javascript:void(0)" class="w3-right w3-button w3-white" onclick="w3_open()">☰</a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:80px">
    <!-- Push down content on small screens -->
    <div class="w3-hide-large" style="margin-top:83px"></div>
    <!-- Modal for full size images on click-->
    <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
        <span class="w3-button w3-black  w3-display-topright">×</span>
        <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
            <p id="caption"></p>
        </div>
    </div>
    <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32" id="about" >
        <div class="w3-content w3-justify" >
            <h2 style="color: aliceblue;padding-left: 250px"><b>Lessons' Grades That You Joined</b></h2>
        </div>
        <!--button for charts -->
        <div style="max-width:600px;padding-left: 1000px;"  >
            <form method="post" enctype="multipart/form-data" action="chartsforstudent.php">
                <input type="hidden" name="s_name" value="<?php echo $s_name ?>">
                <input type="hidden" name="s_username" value="<?php echo $s_username ?>">
                <input type="hidden" name="student_id" value="<?php echo $_SESSION['User_id'] ?>">
                <input type="submit" Value="See The Charts" style="background: #378f7b;color: #D5CCCA;font-family: Garamond;font-weight: bold; text-align: center ;">
            </form>
        </div>
    </div>

      <!-- Table for the performance of a student -->
    <footer class="w3-container w3-padding-32 w3-grey" style="padding-left: 300px">
        <div class="w3-row-padding">
            <div class="w3-third" id="table" >
                <h1 style="color: aliceblue;"><b>Grades</b></h1>
                <?php
                    echo('<table border="1" style="background: #D5CCCA ; width: 400px; " >' . "\n");
                    ?>
                    <tr>
                        <th>Title</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Semester</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Theory Grade</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Laboratory Grade</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Grade</th>
                        <th style="padding-left: 50px;padding-right: 50px;">date</th>
                    </tr>
                    <?php
                    foreach($yourlessons as $row)
                    {

                        ?>
                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" id="l_id" name="l_id" value="<?php echo $row['l_id']; ?>">
                            <?php
                            echo("<tr><td style='width: 270px;'><p style='width: 300px; font-family: Garamond; font-weight: bold; text-align: center ' >");
                            echo(htmlentities($row['title']));
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                            echo(htmlentities($row['semester']));
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                            if($row['finalisegrade']==1) {
                                echo(htmlentities($row['theorygrade']));
                            }
                            else
                            {
                                if($row['theorygrade']>=5 )
                                {
                                    echo(htmlentities($row['theorygrade']));
                                }
                                echo('-');
                            }
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                            if($row['finalisegrade']==1) {
                                echo(htmlentities($row['labgrade']));
                            }
                            else
                            {
                                if($row['labgrade']>=5 )
                                {
                                    echo(htmlentities($row['labgrade']));
                                }
                                else{
                                    echo('-');
                                }

                            }
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center'>");
                            if($row['finalisegrade']==1) {
                                echo(htmlentities($row['grade']));
                            }
                            else
                            {
                                if($row['theorygrade']>=5 )
                                {
                                    echo(htmlentities($row['theorygrade']));
                                }
                                else{
                                    echo('-');
                                }
                            }
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center'>");
                            echo(htmlentities($row['date']));
                            echo("</p></td></tr>");
                            ?>
                        </form>
                        <?php

                    }
                    echo("</table>");

                ?>
            </div>
        </div>
    </footer>
</div>

<script>
    // Script to open and close sidebar
    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }
    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }
    // Modal Image Gallery
    function onClick(element) {
        document.getElementById("img01").src = element.src;
        document.getElementById("modal01").style.display = "block";
        var captionText = document.getElementById("caption");
        captionText.innerHTML = element.alt;
    }
</script>
</body>
</html>


