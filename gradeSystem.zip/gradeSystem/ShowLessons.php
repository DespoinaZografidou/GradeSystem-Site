<?php
require_once 'Classes/PDO.php';
include_once('Classes/DbController.php');

//Give me the lessons info
$viewLessons = new DbController();
$allLessons = $viewLessons->getinfoLesson();

?>
<!DOCTYPE html>
<html lang="en">
<title>AEGEAN ICSD</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="Css/Tables.css"/>
<style>
    body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
    .w3-third img{margin-bottom: -6px; opacity: 0.8; cursor: pointer}
    .w3-third img:hover{opacity: 1}
</style>
<body class="w3-light-grey w3-content" style="max-width:1600px">

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-animate-left w3-text-grey w3-collapse w3-top w3-center" style="z-index:3;width:180px;font-weight:bold" id="mySidebar"><br>
    <img alt='' src='Images/logo.JPG' width='180px' height='150px' ><br><br><br><br><br><br>
    <a href="index.php" onclick="w3_close()" class="w3-bar-item w3-button">Go Back</a>
    <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-padding w3-hide-large">CLOSE</a>
</nav>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-white w3-xlarge w3-padding-16">
    <span class="w3-left w3-padding">SOME NAME</span>
    <a href="javascript:void(0)" class="w3-right w3-button w3-white" onclick="w3_open()">☰</a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:180px">

    <!-- Push down content on small screens -->
    <div class="w3-hide-large" style="margin-top:83px"></div>



    <!-- Modal for full size images on click-->
    <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
        <span class="w3-button w3-black w3-xlarge w3-display-topright">×</span>
        <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
            <img  id="img01"  class="w3-image">
            <p id="caption"></p>
        </div>
    </div>


    <!-- logo of the usiversity -->
    <div class="w3-container w3-center w3-text-light-grey w3-padding-32" id="about" >
        <div  style="max-width:600px;padding-left: 210px;">
            <img alt='' src='Images/logo1.svg' width='800px' height='200px' >
        </div>
    </div>
    <!-- Search section and table with the lesson' data -->
    <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32" id="about" >
        <div class="w3-content w3-justify" style="max-width:600px">
            <form action="" method="post">
                Search: <input type="text" name="term">
                <input type="submit" name="Search" style="background: #4CAF50;" value="Search">
            </form>
            <br>
        </div>
        <h1 style="color: aliceblue;padding-right:900px;"><b>Curriculum</b></h1>
        <div style="padding-left: 100px;" id="table">
            <?php
//            Search for the key word
            $counter=0;
                if(!empty($_POST['term']))
                {
                    $term =$_POST['term'];
                    echo('<table border="1" style="background:#D5CCCA; width: 400px; " >' . "\n");
                    ?>
                    <tr>
                        <th>Title</th>
                        <th>Semester</th>
                        <th>Theory</th>
                        <th>Laboratory</th>
                        <th>Professor</th>
                    </tr>
                    <?php
                    $stmt = $pdo->query("select * from lesson where title like '%$term%' OR semester like '%$term%' ");

                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $t_id=$row["t_id"];
                        $stmt1 = $pdo->query("select * from all_users where u_id like '$t_id'  ");
                        while ($r = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                            $counter++;
                            echo("<tr><td><textarea style='font-family: Garamond; font-weight: bold; text-align: center ' disabled>");
                            echo(htmlentities($row['title']));
                            echo("</textarea></td><td><textarea style='font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                            echo(htmlentities($row['semester']));
                            echo("</textarea></td><td><textarea style='font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                            echo(htmlentities($row['theory']));
                            echo("</textarea></td><td><textarea style='font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                            echo(htmlentities($row['lab']));
                            echo("</textarea></td><td><textarea style=' font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                            echo(htmlentities($r['firstname']));
                            echo(" ");
                            echo(htmlentities($r['lastname']));
                            echo("</textarea></td></tr>");

                        }
                    }
                    echo("</table>");
                }
//                Show me all the lessons' data
                else
                {
                    echo('<table border="1" style="background: #D5CCCA ; width: 400px; " >' . "\n");
                        ?>
                    <tr>
                        <th>Title</th>
                        <th>Semester</th>
                        <th>Theory</th>
                        <th>Laboratory</th>
                        <th>Professor</th>
                    </tr>
                    <?php
                    foreach($allLessons as $row)
                    {
                        $counter++;
                        echo("<tr><td><textarea style='font-family: Garamond; font-weight: bold; text-align: center ' disabled>");
                        echo(htmlentities($row['title']));
                        echo("</textarea></td><td><textarea style='font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                        echo(htmlentities($row['semester']));
                        echo("</textarea></td><td><textarea style='font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                        echo(htmlentities($row['theory']));
                        echo("</textarea></td><td><textarea style='font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                        echo(htmlentities($row['lab']));
                        echo("</textarea></td><td><textarea style=' font-family: Garamond; font-weight: bold;  text-align: center' disabled>");
                        echo(htmlentities($row['firstname']));
                        echo(" ");
                        echo(htmlentities($row['lastname']));
                        echo("</textarea></td></tr>");
                    }
                    echo("</table>");
                }
                //if there is not lessons in the database don't show the table
            if($counter==0)
            {
                ?>
                <script>
                    document.getElementById("table").style.display = "none";
                </script>

                <?php
            }
            ?>

        </div>
    </div>


    <!-- Contact section -->
    <div class="w3-container w3-light-grey w3-padding-32 w3-padding-large" id="contact">
        <div class="w3-content" style="max-width:600px">

        </div>
    </div>

</div>

<div class="w3-black w3-center w3-padding-24"></div>
<!-- End page content -->
</div>

<script>
    // Script to open and close sidebar
    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }

    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }

    // Modal Image Gallery
    function onClick(element) {
        document.getElementById("img01").src = element.src;
        document.getElementById("modal01").style.display = "block";
        var captionText = document.getElementById("caption");
        captionText.innerHTML = element.alt;
    }

</script>


</body>
</html>


