<?php
require_once '../Classes/PDO.php';

$stmt = $pdo->prepare('SELECT count(*)g, CASE WHEN grade>= 5 THEN "Successfull" ELSE "Failed" END as c FROM join_lesson WHERE l_id="'.$_POST['id1'].'" AND YEAR(date)=YEAR(CURDATE()) GROUP by c');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_OBJ);
echo json_encode($results);
