<?php
//----------------charts for a students see how many courses passed successfully the lesson in this year in this semester -----
require_once '../Classes/PDO.php';

$stmt = $pdo->prepare('SELECT count(*)g,CASE WHEN grade>=5 THEN "Successfull" ELSE "Failed" END as c FROM join_lesson WHERE s_id="'.$_POST['id1'].'" AND YEAR(date)=YEAR(CURDATE()) AND CASE WHEN MONTH(CURRENT_DATE)<7 AND MONTH(CURRENT_DATE)>1 THEN MONTH(date)<7 WHEN MONTH(CURRENT_DATE)=9 THEN MONTH(date)<=12 ELSE MONTH(date)<=12 AND MONTH(date)>9 END GROUP by c');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_OBJ);
echo json_encode($results);

