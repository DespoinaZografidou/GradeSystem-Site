<?php
//----------------charts for a teacher see the joins in a lesson------------>
require_once '../Classes/PDO.php';

$stmt = $pdo->prepare('SELECT YEAR(join_lesson.date)y, COUNT(join_lesson.l_id)ct FROM join_lesson WHERE join_lesson.l_id="'.$_POST['id'].'" GROUP BY y');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_OBJ);
echo json_encode($results);
