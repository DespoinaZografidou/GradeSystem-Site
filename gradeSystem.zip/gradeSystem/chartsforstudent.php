<?php
require_once 'Classes/PDO.php';

if(isset($_POST['student_id']))
{
    $id=$_POST['student_id'];
    $username=$_POST['s_username'];
    $s_name=$_POST['s_name'];
}

?>


<html lang="en">
<head>
    <!--    ----------------charts for a student see the lessons for this semester------------>
    <input type="hidden"  id='id' value=<?php echo $id; ?>>
    <title><?php echo $s_name ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script
        src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

    <script type="text/javascript"
            src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">

        $(document).ready(function() {
            var id1 = document.getElementById('id').value;
            $.ajax({
                url : "charts/Studentswhopasesinthisyear.php",
                method:"POST",
                data:{id1:id1},
                dataType : "JSON",
                success : function(result) {
                    google.charts.load('current', {
                        'packages' : [ 'corechart' ]
                    });
                    google.charts.setOnLoadCallback(function() {
                        drawChart1(result);
                    });
                }
            });

            function drawChart1(result) {

                var data = new google.visualization.DataTable();
                data.addColumn('string', 'g');
                data.addColumn('number', 'c');
                var dataArray = [];
                $.each(result, function(i, obj) {
                    dataArray.push([ obj.c, parseInt(obj.g)]);

                });

                data.addRows(dataArray);

                var piechart_options = {
                    title : 'Pie Chart: How many courses are passed successfully this semester <?php echo date("Y") ?> ',
                    width : 400,
                    height : 300
                };
                var piechart = new google.visualization.PieChart(document
                    .getElementById('piechart_div'));
                piechart.draw(data, piechart_options);

            }

        });
    </script>
</head>

<body style="background: #A0A0A0;">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="Css/Tables.css"/>
<style>
    body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
    .w3-third img{margin-bottom: -6px; opacity: 0.8; cursor: pointer}
    .w3-third img:hover{opacity: 1}
</style>
<!--SIDE BAR-->
<nav class="w3-sidebar w3-bar-block w3-white w3-animate-left w3-text-grey w3-collapse w3-top w3-center" style="z-index:3;width:180px;font-weight:bold" id="mySidebar"><br>
    <img alt='' src='Images/logo.JPG'width='180px' height='150px' ><br>
    <hr>
</nav>
<!--THE TITLE-->
<div style="background: #696969;position: absolute;top:0px; left:0px; width: 100%;">
    <h1 style="color: aliceblue;text-align: center;">Statistical Data for the students this year and semester<b></b></h1>
    <h2 style="color: aliceblue;text-align: center;"><?php echo $username?> - <?php echo(htmlentities($s_name)); ?> <b></b></h2>

</div>
<!--SHOW THE CHARTS-->
<div style="position: absolute;left:400px; top:150px;">
    <table class="columns">

        <tr>
            <td>
                <div id="piechart_div" style="border: 1px solid #ccc"></div>
            </td>
        </tr>
    </table>
</div>
<!--SHOW ME THE GENERAL STATISTICS DATA FOR THE STUDENT-->
<div style="position: absolute;left:400px; top:480px;width: 800px;">
    <h3 style="color: aliceblue;">The the generic data of <?php echo (htmlentities($s_name)); ?> as student in the University</h3>
    <?php
    $stmt = $pdo->query("SELECT (SELECT COUNT(*) FROM join_lesson WHERE join_lesson.s_id='".$id."' AND join_lesson.grade>=5)a,(SELECT COUNT(*) FROM join_lesson WHERE join_lesson.s_id='".$id."' AND join_lesson.grade<5)b");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        ?>
        <p>The total number of courses in this year were <?php echo ($row['a']+$row['b']); ?> .</p>
        <p>The total number of courses that were passed successfully are  <?php echo $row['a']; ?>  courses and the total number of courses that were not passed successfully are <?php echo $row['b']; ?> courses.</p>
        <p>In conclusion, <?php echo ($row['a'] * 100/($row['a']+$row['b'])); ?>% of the courses are successfully passed and <?php echo ($row['b'] * 100/($row['a']+$row['b'])); ?>% the courses are not successfully passed this year.</p>
        <?php
    }
    ?>
</div>

</body>
</html>

