<?php
require_once 'Classes/PDO.php';
include_once('Classes/DbController.php');

session_start();
//if you not allowed to insert in the site through the login form go back to the login form
if( $_SESSION['access']!='true')
{
    header('Location: index.php');
}
//Show the lessons of the database
$viewLessons = new DbController();
$allLessons = $viewLessons->getinfoLesson();

//get the user who he/she is in the system for the side bar
$viewUsers = new DbController();
$allUsers = $viewUsers->getUser();

//join in a lesson
if(isset($_POST['Join']))
{
    $s_id=$_SESSION['User_id'];
    $l_id=$_POST['l_id'];
    $addparticipant=new DbController();
    $addparticipant->AddPartitipant($l_id,$s_id);


}
//delete a join from a lesson
if(isset($_POST['delete']))
{
    $s_id=$_SESSION['User_id'];
    $l_id=$_POST['get_id'];
    $canceljoin=new DbController();
    $canceljoin->CancelJoin($l_id,$s_id);
}

?>

<!DOCTYPE html>
<html lang="en">
<title>AEGEAN ICSD</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="Css/Tables.css"/>
<style>
    body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
    .w3-third img{margin-bottom: -6px; opacity: 0.8; cursor: pointer}
    .w3-third img:hover{opacity: 1}
</style>
<body class="w3-light-grey w3-content" style="max-width:1600px">

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-animate-left w3-text-grey w3-collapse w3-top w3-center" style="z-index:3;width:180px;font-weight:bold" id="mySidebar"><br>
    <img alt='' src='Images/logo.JPG' width='180px' height='150px' ><br>
    <hr>
    <?php

    foreach($allUsers as $row)
    {
        if($row['u_id']==$_SESSION['User_id']) {
            echo "<img alt='' src='userImages/".$row['image']."' width='100px' height='100px' style=' border-radius: 50%;'><br>";
            echo $row['username'];
        }
    }

    ?>
    <hr>
    <a href="UserProfile.php" onclick="w3_close()" class="w3-bar-item w3-button">Profile</a>

    <?php
    if($_SESSION['role']=='Teacher')
    {
        ?>
        <a href="Professor'sLessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Lessons</a>
        <?php
    }
    else{
        ?>
        <a href="UserSeeGrades&Lessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Grades</a>
        <?php
        $checkallow=new DbController();
        $allow=$checkallow->CheckAllow();
        foreach ($allow as $a)  {
            if($a['Allow']==1){
                ?>
                <a href="UsersJoinLessons.php" onclick="w3_close()" class="w3-bar-item w3-button">Courses' Declaration</a>

                <?php
            }
        }
    }
    ?>
    <a href="index.php" onclick="w3_close()" class="w3-bar-item w3-button">Log Out</a>
    <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-padding w3-hide-large">CLOSE</a>
</nav>


<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-white w3-xlarge w3-padding-16">
    <span class="w3-left w3-padding">MENU</span>
    <a href="javascript:void(0)" class="w3-right w3-button w3-white" onclick="w3_open()">☰</a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:80px">
    <!-- Push down content on small screens -->
    <div class="w3-hide-large" style="margin-top:83px"></div>
    <!-- Modal for full size images on click-->
    <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
        <span class="w3-button w3-black  w3-display-topright">×</span>
        <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
            <p id="caption"></p>
        </div>
    </div>

    <!-- FORM TO SEARCH A LESSON -->
    <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32" id="about" >
        <div class="w3-content w3-justify" >
            <div style="padding-left: 280px;">
                <form action="" method="post">
                    Search: <input type="text" name="term">
                    <input type="submit" name="Search" style="background: #4CAF50;" value="Search">
                </form>
            </div>
        </div>
    </div>

    <!-- table for lessons' info-->
    <footer class="w3-container w3-padding-32 w3-grey" style="padding-left: 300px">
        <div class="w3-row-padding">
            <div class="w3-third" id="table" >
                <h1 style="color: aliceblue;"><b>Courses</b></h1>
                <?php
                $counter=0;
                // if the search textfield is not empty show me the table with the rows that match with the key word
                if(!empty($_POST['term']))
                {
                    echo('<table border="1" style="background: #D5CCCA ; width: 400px; " >' . "\n");
                    ?>
                    <tr>
                        <th>Title</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Semester</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Theory</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Laboratory</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Professor</th>
                        <th>...............</th>

                    </tr>
                    <?php
                    $term =$_POST['term'];
                    $stmt = $pdo->query("select * from lesson where title like '%$term%' OR semester like '%$term%' ");
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $t_id=$row["t_id"];
                        $stmt1 = $pdo->query("select * from all_users where u_id like '$t_id'  ");
                        while ($r = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                            $counter++;
                            ?>
                            <form method="post" enctype="multipart/form-data">
                                <input type="hidden" id="l_id" name="l_id" value="<?php echo $row['l_id']; ?>">
                                <?php
                                echo("<tr><td style='width: 270px;'><p style='width: 300px; font-family: Garamond; font-weight: bold; text-align: center ' >");
                                echo(htmlentities($row['title']));
                                echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                                echo(htmlentities($row['semester']));
                                echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                                echo(htmlentities($row['theory']));
                                echo("</p></td><td><p  style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                                echo(htmlentities($row['lab']));
                                echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center'>");
                                echo(htmlentities($r['firstname']));
                                echo(" ");
                                echo(htmlentities($r['lastname']));
                                echo("</p></td><td>");
                                $check=new DbController();
                                $checkjoin=$check->CheckJoins();
                                $checkcounter=0;
                                foreach ($checkjoin as $r)
                                {
                                    if($r['s_id']== $_SESSION['User_id']) {
                                        if($r['l_id']==$row['l_id']) {
                                            $checkcounter++;
                                        }
                                    }

                                }
                                if($checkcounter==0)
                                {

                                ?>
                                    <input type="submit"  value='Join' name='Join' style='font-size: 70%;background-image: linear-gradient(160deg, green 0%, #378f7b 100%);color: #fff;width: 60%;border: 1px solid #242c37;border-radius: 30%;text-align: center;'>
                                <?php
                                }
                                else{
                                    ?>
                                    <input type="button" value="x" onclick="Show('<?php echo $row['l_id'] ?>','<?php echo $row['title'] ?>')" style="font-size: 70%;background-image: linear-gradient(160deg, #B22222 0%, #378f7b 100%);color: #fff;width: 60%;border: 1px solid #242c37;border-radius: 30%;text-align: center;">
                                    <?php

                                }
                                echo("</td></tr>");
                                ?>
                            </form>
                            <?php
                        }
                    }
                    echo("</table>");
                }
//                if textfield is empty show all the rows with the lessons from database
                else{

                    echo('<table border="1" style="background: #D5CCCA ; width: 400px; " >' . "\n");
                    ?>
                    <tr>
                        <th>Title</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Semester</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Theory</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Laboratory</th>
                        <th style="padding-left: 20px;padding-right: 20px;">Professor</th>
                        <th>...............</th>

                    </tr>
                    <?php
                    foreach($allLessons as $row)
                    {
                        $counter++;
                        ?>
                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" id="l_id" name="l_id" value="<?php echo $row['l_id']; ?>">

                            <?php
                            echo("<tr><td style='width: 270px;'><p style='width: 300px; font-family: Garamond; font-weight: bold; text-align: center ' >");
                            echo(htmlentities($row['title']));
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                            echo(htmlentities($row['semester']));
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                            echo(htmlentities($row['theory']));
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center' >");
                            echo(htmlentities($row['lab']));
                            echo("</p></td><td><p style='font-family: Garamond; font-weight: bold;  text-align: center'>");
                            echo(htmlentities($row['firstname']));
                            echo(" ");
                            echo(htmlentities($row['lastname']));
                            echo("</p></td><td>");
                            $check=new DbController();
                            $checkjoin=$check->CheckJoins();
                            $checkcounter=0;
                            //check if the student is already participant in this lesson
                            foreach ($checkjoin as $r)
                            {
                                if($r['s_id']== $_SESSION['User_id']) {
                                    if($r['l_id']==$row['l_id']) {
                                        $checkcounter++;
                                    }
                                }

                            }
                            //if the student is not participate in the lesson
                            if($checkcounter==0)
                            {

                            ?>
                                <input type="submit"  value='Join' name='Join' style='font-size: 70%;background-image: linear-gradient(160deg, green 0%, #378f7b 100%);color: #fff;width: 60%;border: 1px solid #242c37;border-radius: 30%;text-align: center;'>

                            <?php
                            }
                            else{
                                ?>
                                <input type="button" onclick="Show('<?php echo $row['l_id'] ?>','<?php echo $row['title'] ?>')"  value="x"  style="font-size: 70%;background-image: linear-gradient(160deg, #B22222 0%, #378f7b 100%);color: #fff;width: 60%;border: 1px solid #242c37;border-radius: 30%;text-align: center;">
                                <?php

                            }
                            echo("</td></tr>");
                            ?>
                        </form>
                        <?php
                    }
                    echo("</table>");
                }
//                if there is not any lessons in the database don't show the table
                if($counter==0)
                {
                    ?>
                    <script>
                        document.getElementById("table").style.display = "none";
                    </script>

                    <?php
                }
                ?>
            </div>
        </div>
    </footer>
</div>


<!--POP UP FORM TO CANCEL A JOIN IN A LESSON  -->
<div class="modal" id="popDelete" style="display: none; background-color: #CEEAE5;position: fixed;top:50%;left:50%;transform : translate(-50%,-50%) ;border:1px solid black;border-radius:10px;z-index:10;width:420px;max-width:80%; height: 120px; overflow: auto;">

    <div class="modal-head" style="display:flex; justify-content: space-between; align-items: center;padding: 10px 15px;">

        <div class="title" style="font-size:12px;font-weight:bold;">
            <p>Are you sure that you want to leave from the lesson :</p>
            <input type="text" id="viewtitle" disable>
        </div>
        <button onclick="Hide()" style="cursor:pointer;border: none;outline: none;background:white;font-size:1rem;font-weight: bold;"  >&times;</button>
    </div>
    <form method="post" action="" style="padding-right: 5%">
        <input type="hidden" value="" id="get_id" name="get_id">
        <input type="submit" style="float:right; border:1px solid black; " value="Διαγραφή" id="delete" name="delete"><br>
    </form>
</div>


<script>
    // Script to open and close sidebar
    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }
    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }
    // Modal Image Gallery
    function onClick(element) {
        document.getElementById("img01").src = element.src;
        document.getElementById("modal01").style.display = "block";
        var captionText = document.getElementById("caption");
        captionText.innerHTML = element.alt;
    }

    // ----------- SHOW THE WINDOW TO CANCEL A JOIN----------
    function Show($l_id,$title)
    {
        document.getElementById("get_id").value=$l_id;
        document.getElementById("viewtitle").value=$title;
        var v = document.getElementById("popDelete");
        if (v.style.display === "block") {
            v.style.display = "none";
        } else {
            v.style.display = "block";
        }

    }

    //----------- HIDE THE WINDOW TO CANCEL A JOIN----------
    function Hide()
    {
        var v = document.getElementById("popDelete");
        if (v.style.display === "none") {
            v.style.display = "block";
        } else {
            v.style.display = "none";
        }
    }


</script>
</body>
</html>

